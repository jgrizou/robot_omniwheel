#ifndef __CREDENTIALS_H__
#define __CREDENTIALS_H__

// Wifi parameters
char ssid[] = "YourSSID";
char passphrase[] = "YourSecretPassPhrase123";
char ntp_server[] = "64.147.116.229"  // "nist1-la.ustiming.org"; // or your favorite ntp server.

#define TIMEZONE_GMT_OFFSET  -7

#endif
